<?php
/**
 * Shield Job Portal — Database Connection Config
 * ------------------------------------------------
 * Targets the EXISTING WordPress database (wordpress-35303837748d)
 * as confirmed. Only jp_* prefixed tables belong to this app.
 *
 * SECURITY — before you deploy:
 *   1. Move this file OUTSIDE the public web root if your hosting
 *      allows it (e.g. one level above public_html), and require()
 *      it from there instead. If it must stay inside the web root,
 *      keep the .htaccess in this folder — it blocks direct
 *      browser access to *.php config files.
 *   2. Never commit this file (with real credentials) to a public
 *      Git repository. Add /config/db_config.php to .gitignore and
 *      commit a db_config.example.php with blank values instead.
 *   3. Rotate the MySQL password if this file, the docx it came
 *      from, or this chat log is ever shared outside your team —
 *      both are now on record as plain text.
 */

// --- Connection details (from your host's hosting panel) ---
define('DB_HOST', '185.151.30.226');
define('DB_PORT', '3306');
define('DB_NAME', 'wordpress-35303837748d');   // existing DB you confirmed
define('DB_USER', 'wordpress-35303837748d');   // paired user for that DB, per your host's naming convention
define('DB_PASS', 'Rajiv#2026');
define('DB_CHARSET', 'utf8mb4');

/**
 * NOTE: your details doc also listed a second MySQL user,
 * `dbjobportal` (same password), which is not the pair typically
 * used to connect to a `wordpress-...` named database on StackCP-
 * style hosting. If the connection below fails with an access-
 * denied error, open phpMyAdmin → the database → "Privileges" tab
 * and confirm exactly which username has GRANT access to
 * `wordpress-35303837748d`, then update DB_USER above to match.
 */

function getDbConnection(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = sprintf(
        'mysql:host=%s;port=%s;dbname=%s;charset=%s',
        DB_HOST,
        DB_PORT,
        DB_NAME,
        DB_CHARSET
    );

    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION, // fail loudly instead of silently
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,                  // real prepared statements — blocks SQL injection
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        // Never echo $e->getMessage() to the browser in production —
        // it can leak host/user details to an attacker.
        error_log('DB connection failed: ' . $e->getMessage());
        http_response_code(500);
        die('Service temporarily unavailable.');
    }

    return $pdo;
}
